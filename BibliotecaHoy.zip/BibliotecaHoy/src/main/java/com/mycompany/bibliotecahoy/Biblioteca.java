package com.mycompany.bibliotecahoy;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Clase que gestiona la biblioteca y sus operaciones.
 */
public class Biblioteca {
    private final Map<String, Libro> libros; // Mapa para almacenar los libros por ISBN
    private final Set<String> reservas; // Conjunto para almacenar ISBN de libros reservados

    // Definición de constantes para los mensajes de excepción
    private static final String LIBRO_NO_EXISTE = "El libro con ISBN %s no existe.";
    private static final String LIBRO_YA_RESERVADO = "El libro con ISBN %s ya está reservado.";
    private static final String LIBRO_NO_RESERVADO = "El libro con ISBN %s no está reservado.";
    private static final String LIBRO_DUPLICADO = "El libro con ISBN %s ya está en la biblioteca.";

    /**
     * Constructor de la clase Biblioteca.
     * Inicializa los mapas y conjuntos utilizados en la gestión de la biblioteca.
     */
    public Biblioteca() {
        libros = new HashMap<>();
        reservas = new HashSet<>();
    }

    /**
     * Agrega un libro a la biblioteca.
     * @param libro Libro a agregar.
     * @throws LibroDuplicadoException Si el libro ya existe en la biblioteca.
     */
    public void agregarLibro(Libro libro) throws LibroDuplicadoException {
        if (libros.containsKey(libro.getIsbn())) {
            throw new LibroDuplicadoException(String.format(LIBRO_DUPLICADO, libro.getIsbn()));
        }
        libros.put(libro.getIsbn(), libro);
    }

    /**
     * Reserva un libro por su ISBN.
     * @param isbn ISBN del libro a reservar.
     * @throws LibroNoDisponibleException Si el libro no existe o ya está reservado.
     */
    public void reservarLibro(String isbn) throws LibroNoDisponibleException {
        if (!libros.containsKey(isbn)) {
            throw new LibroNoDisponibleException(String.format(LIBRO_NO_EXISTE, isbn));
        }
        if (reservas.contains(isbn)) {
            throw new LibroNoDisponibleException(String.format(LIBRO_YA_RESERVADO, isbn));
        }
        reservas.add(isbn);
    }

    /**
     * Cancela la reserva de un libro por su ISBN.
     * @param isbn ISBN del libro cuya reserva se desea cancelar.
     * @throws LibroNoDisponibleException Si el libro no está reservado.
     */
    public void cancelarReserva(String isbn) throws LibroNoDisponibleException {
        if (!reservas.contains(isbn)) {
            throw new LibroNoDisponibleException(String.format(LIBRO_NO_RESERVADO, isbn));
        }
        reservas.remove(isbn);
    }
}
