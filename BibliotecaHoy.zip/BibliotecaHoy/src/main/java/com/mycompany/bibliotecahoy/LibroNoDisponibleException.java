package com.mycompany.bibliotecahoy;

/**
 * Excepción personalizada para manejar casos en los que un libro no está disponible.
 */
public class LibroNoDisponibleException extends Exception {
    public LibroNoDisponibleException(String message) {
        super(message);
    }
}
