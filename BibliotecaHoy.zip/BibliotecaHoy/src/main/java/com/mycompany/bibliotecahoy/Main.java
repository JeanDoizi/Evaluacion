package com.mycompany.bibliotecahoy;

public class Main {
    private static final String ISBN_LIBRO_1 = "978-3-16-148410-0";
    private static final String ISBN_LIBRO_2 = "978-1-4028-9462-6";
    
    public static void main(String[] args) {
        // Crear una instancia de Biblioteca
        Biblioteca biblioteca = new Biblioteca();

        // Crear algunos libros de prueba
        Libro libro1 = new Libro(ISBN_LIBRO_1, "El Gran Libro", "Autor A");
        Libro libro2 = new Libro(ISBN_LIBRO_2, "El Segundo Libro", "Autor B");

        // Agregar libros a la biblioteca
        try {
            biblioteca.agregarLibro(libro1);
            biblioteca.agregarLibro(libro2);
            System.out.println("Libros agregados con éxito.");
        } catch (LibroDuplicadoException e) {
            System.err.println(e.getMessage());
        }

        // Reservar un libro
        try {
            biblioteca.reservarLibro(ISBN_LIBRO_1);
            System.out.println("Libro reservado con éxito.");
        } catch (LibroNoDisponibleException e) {
            System.err.println(e.getMessage());
        }

        // Intentar reservar el mismo libro nuevamente
        try {
            biblioteca.reservarLibro(ISBN_LIBRO_1);
        } catch (LibroNoDisponibleException e) {
            System.err.println("Error al reservar el libro: " + e.getMessage());
        }

        // Cancelar la reserva de un libro
        try {
            biblioteca.cancelarReserva(ISBN_LIBRO_1);
            System.out.println("Reserva cancelada con éxito.");
        } catch (LibroNoDisponibleException e) {
            System.err.println("Error al cancelar la reserva: " + e.getMessage());
        }
    }
}
