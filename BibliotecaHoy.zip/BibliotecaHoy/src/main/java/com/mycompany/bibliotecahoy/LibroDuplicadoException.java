package com.mycompany.bibliotecahoy;

/**
 * Excepción personalizada para manejar casos en los que un libro ya existe.
 */
public class LibroDuplicadoException extends Exception {
    public LibroDuplicadoException(String message) {
        super(message);
    }
}
